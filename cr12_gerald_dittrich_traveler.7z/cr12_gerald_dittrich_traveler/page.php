<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_gerald_dittrich_traveler
 */

get_header();
?>
	<div class="container">
		
	
	<!-- 	<div class="h1 text-center">
			<b>Mount Everest travel agency</b>
		</div>
		 -->


		<img src="https://cdn.prod.www.spiegel.de/images/bf1dae14-0001-0004-0000-000001431732_w948_r1.77_fpx38.35_fpy49.98.jpg" alt="mt. everest">


		<div class="">
			<br>
			Welcome to the blog of Mount Everest travel agency. 
			Here we will show you interesting news about all the travel destinations we offer.
		</div>
	
	<div id="primary" class="content-area" style="max-width: 950px;">
		<main id="main" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->
	
<?php
get_sidebar();
get_footer();
?>
</div>